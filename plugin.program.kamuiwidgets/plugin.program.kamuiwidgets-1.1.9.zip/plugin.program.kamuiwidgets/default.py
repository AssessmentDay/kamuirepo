import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.kamuiwidgets'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.kamuiwidgets'
AddonTitle="Kamui Widgets"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.1.3"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Kamui Widgets"            
BASEURL = "http://kamui.ga"
H = 'http://'
EXCLUDES     = ['']

def INDEX():
    setView('movies', 'MAIN')

def MOVIESBUTTON1():
    addDir('Kamui Streams','url',20,ART+'kamuistreams.png',FANART,'')
    addDir('Neptune Rising','url',21,ART+'neptune.png',FANART,'')
    addDir('AtTheFlix','url',22,ART+'attheflix.png',FANART,'')
    #addDir('Selfless Lite','url',23,ART+'sli.png',FANART,'')
    addDir('Gaia','url',24,ART+'gaia.png',FANART,'')
    setView('movies', 'MAIN')

def MOVIESBUTTON2():
    #addDir('Gaia','url',24,ART+'gaia.png',FANART,'')
    setView('movies', 'MAIN')

def TVSHOWSBUTTON1():
    addDir('Kamui Streams','url',30,ART+'kamuistreams.png',FANART,'')
    addDir('Neptune Rising','url',31,ART+'neptune.png',FANART,'')
    addDir('AtTheFlix','url',32,ART+'attheflix.png',FANART,'')
    #addDir('Selfless Lite','url',33,ART+'sli.png',FANART,'')
    addDir('Gaia','url',34,ART+'gaia.png',FANART,'')
    setView('movies', 'MAIN')

def TVSHOWSBUTTON2():
    #addDir('Gaia','url',34,ART+'gaia.png',FANART,'')
    addDir('Documented.HD','url',35,ART+'documented.png',FANART,'')
    setView('movies', 'MAIN')

def KIDSBUTTON1():
    addDir('Kamui Kids','url',40,ART+'kamuikids.png',FANART,'')
    addDir('AtTheFlix','url',41,ART+'attheflix.png',FANART,'')
    addDir('Cartoon HD','url',42,ART+'cartoonhd.png',FANART,'')
    addDir('Little Baby Bum','url',43,ART+'lbb.png',FANART,'')
    setView('movies', 'MAIN')

def KIDSBUTTON2():
    addDir('Kids Movies','url',44,ART+'kidsmovies.png',FANART,'')
    addDir('BinkyTV','url',45,ART+'binkytv.png',FANART,'')
    setView('movies', 'MAIN')

def LIVETVBUTTON1():
    addDir('TV Player','url',50,ART+'tvplayer.png',FANART,'')
    addDir('BBC IPlayer','url',51,ART+'bbciplayer.png',FANART,'')
    addDir('ITV Player','url',52,ART+'itvplayer.png',FANART,'')
    addDir('UKTV Play','url',53,ART+'uktvplay.png',FANART,'')
    setView('movies', 'MAIN')

def LIVETVBUTTON2():
    addDir('Vader Streams','url',54,ART+'vader.png',FANART,'')
    setView('movies', 'MAIN')

def MUSICBUTTON():
    addDir('MTV Music','url',60,ART+'mtv.png',FANART,'')
    addDir('Youtube Music','url',61,ART+'youtubemusic.png',FANART,'')
    addDir('Monstercat Youtube','url',62,ART+'monstercat.png',FANART,'')
    addDir('XFactor','url',63,ART+'xfactor.png',FANART,'')
    setView('movies', 'MAIN')

def SPORTSBUTTON1():
    addDir('PlanetMMA','url',70,ART+'planetmma.png',FANART,'')
    addDir('WrestleManiac','url',71,ART+'wrestlemaniac.png',FANART,'')
    addDir('Sparkle','url',72,ART+'sparkle.png',FANART,'')
    addDir('Joker Sports','url',73,ART+'jokersports.png',FANART,'')
    setView('movies', 'MAIN')
    
def SPORTSBUTTON2():
    addDir('Skynet Sports','url',74,ART+'skynetsports.png',FANART,'')
    addDir('Sports Devil','url',75,ART+'sportsdevil.png',FANART,'')
    setView('movies', 'MAIN')

def ONLINEBUTTON1():
    addDir('Twitch','url',80,ART+'twitch.png',FANART,'')
    addDir('Youtube','url',81,ART+'youtube.png',FANART,'')
    addDir('UFC on Youtube','url',82,ART+'mmayoutube.png',FANART,'')
    addDir('WWE On Youtube','url',83,ART+'wweyoutube.png',FANART,'')
    setView('movies', 'MAIN')

def ONLINEBUTTON2():
    addDir('JRE','url',84,ART+'jre.png',FANART,'')
    addDir('Live Tube','url',85,ART+'livetube.png',FANART,'')
    setView('movies', 'MAIN')

def ANIMEBUTTON():
    addDir('9Anime','url',90,ART+'9anime.png',FANART,'')
    addDir('MasterAni Redux','url',91,ART+'masterani.png',FANART,'')
    addDir('Watch Nixtoons','url',93,ART+'watchnixtoons.png',FANART,'')
    setView('movies', 'MAIN')

def UPDATEBUTTON1():
    addDir('Kamui Wizard','url',100,ART+'kamuiwizard.png',FANART,'')
    addDir('Fix Buffering','url',101,ART+'fixbuffer.png',FANART,'')
    addDir('Refresh Repos','url',102,ART+'fixskin.png',FANART,'')
    addDir('Fresh Start','url',103,ART+'freshstart.png',FANART,'')
    setView('movies', 'MAIN')

def UPDATEBUTTON2():
    addDir('Real Debrid','url',104,ART+'rdlogo.png',FANART,'')
    addDir('Trakt','url',105,ART+'traktlogo.png',FANART,'')
    addDir('Logins','url',106,ART+'loginlogo.png',FANART,'')
    setView('movies', 'MAIN')


#################################
##### HOMESCREEN SHORTCUTS ######
#################################

def MOVIES1():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.kamui)")

def MOVIES2():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.neptune)")

def MOVIES3():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.AtTheFlix)")

def MOVIES4():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.sli)")

def MOVIES5():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.gaia)")
    
def TVSHOWS1():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.kamui)")

def TVSHOWS2():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.neptune)")

def TVSHOWS3():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.AtTheFlix)")

def TVSHOWS4():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.sli)")
    
def TVSHOWS5():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.gaia)")
    
def TVSHOWS6():
    import xbmc
    xbmc.executebuiltin("RunAddon(plugin.video.documented.hd)")
    
def KIDS1():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.kamui/?action=kidscorner,return)')

def KIDS2():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.AtTheFlix/?description=No%20information%20available&amp;mode=get_list&amp;name=%5bCOLOR%20red%5d%5bB%5dKids%20Movie%20Boxsets%5b%2fB%5d%5b%2fCOLOR%5d&amp;url=https%3a%2f%2fpastebin.com%2fraw%2ffmUTKku0,return)')

def KIDS3():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.cartoonhd,return)')

def KIDS4():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.youtube.lbb,return)')

def KIDS5():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.kmERlink,return)')

def KIDS6():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.binkytv,return)')

def LIVETV1():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.tvplayer)')

def LIVETV2():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.iplayerwww)')

def LIVETV3():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.itv)')

def LIVETV4():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.uktvplay)')

def LIVETV5():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.VADER,return)')

def MUSIC1():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.mdmtvuk)')

def MUSIC2():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.spotitube)')

def MUSIC3():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.youtube.monstercat)')

def MUSIC4():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.XFactorInternational)')

def SPORTS1():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.ufc-finest)')

def SPORTS2():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.wrestlemaniac,return)')

def SPORTS3():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.sparkle)')

def SPORTS4():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.JokerSports)')

def SPORTS5():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10025,plugin://plugin.video.SkyNet/?mode=1&amp;name=%5bCOLOR%20white%5dSkynet%20Sports%5b%2fCOLOR%5d&amp;url=https%3a%2f%2fpastebin.com%2fraw%2f8LwbCQkv,return)')

def SPORTS6():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.SportsDevil)')

def ONLINE1():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.twitch)')

def ONLINE2():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.youtube)')

def ONLINE3():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.ytMMA)')

def ONLINE4():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.wwe-on-youtube)')

def ONLINE5():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.jre.tva)')

def ONLINE6():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.LiveTube)')

def ANIME1():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.9anime)')

def ANIME2():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.masteraniredux)')

def ANIME4():
    import xbmc
    xbmc.executebuiltin('RunAddon(plugin.video.watchnixtoons)')

def UPDATE1():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard,return)')

def UPDATE2():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard/?mode=autoadvanced,return)')

def UPDATE3():
    import xbmc
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('xbmc.activatewindow(home)')
    dialog = xbmcgui.Dialog()
    dialog.ok("Repos Refreshed", "Please allow a few minutes for addon updates.")

def UPDATE4():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard/?mode=freshstart,return)')

def UPDATE5():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard/?mode=realdebrid,return)')

def UPDATE6():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard/?mode=trakt,return)')
    
def UPDATE7():
    import xbmc
    xbmc.executebuiltin('ReplaceWindow(10001,plugin://plugin.program.kamuiwizard/?mode=login,return)')

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes('Kamui Widgets', 'Welcome to Kamui')
        
    

#################################
####BUILD INSTALL################
#################################

def WIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("Kamui Widgets","Downloading ",'', 'Please Wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting,")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("Kamui Widgets", "To save changes you now need to force close Kodi, Press OK to force close Kodi")
    killxbmc()



################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Kamui Widgets", "Packages Successfuly Removed", "[COLOR yellow]Brought To You By Kamui[/COLOR]")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("Kamui Widgets", "Sorry we were not able to remove Package Files", "[COLOR yellow]Brought To You By Kamui[/COLOR]")
    


#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
	
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("Kamui Widgets", " All Cache Files Removed", "[COLOR yellow]Brought To You By Kamui[/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
	choice = plugintools.message_yes_no('Force Close Kodi', 'You are about to close Kodi','Would you like to continue?')
	if choice == 0:
		return
	elif choice == 1:
		pass
	myplatform = platform()
	print "Platform: " + str(myplatform)

	try:
		os._exit(1)
	except:
		pass

	if myplatform == 'osx':  # OSX
		print "############   try osx force close  #################"
		try:
			os.system('killall -9 XBMC')
		except:
			pass
		try:
			os.system('killall -9 Kodi')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'linux':  # Linux
		print "############   try linux force close  #################"
		try:
			os.system('killall XBMC')
		except:
			pass
		try:
			os.system('killall Kodi')
		except:
			pass
		try:
			os.system('killall -9 xbmc.bin')
		except:
			pass
		try:
			os.system('killall -9 kodi.bin')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'android':  # Android

		print "############   try android force close  #################"

		try:
			os._exit(1)
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.xbmc')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.semperpax.spmc16')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.spmc16')
		except:
			pass
		time.sleep(5)
		plugintools.message(AddonTitle,"Press the HOME button on your remote and [COLOR=red][b]FORCE STOP[/b][/COLOR] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows':  # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", "Use task manager and NOT ALT F4")
	else:  # ATV
		print "############   try atv force close  #################"
		try:
			os.system('killall AppleTV')
		except:
			pass
		print "############   try raspbmc force close  #################"  # OSMC / Raspbmc
		try:
			os.system('sudo initctl stop kodi')
		except:
			pass
		try:
			os.system('sudo initctl stop xbmc')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")


# Get Current platform
def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'   

##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with Kamui","Please reboot your system or restart Kodi in order for the changes to be applied.")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with Kamui","Please reboot your system or restart Kodi in order for the changes to be applied.")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Now Exit Kodi",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","has not been changed"); plugintools.add_item(action="",title="Done",folder=False)

          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        BUILDMENU()

elif mode==3:
        MAINTENANCE()
		
elif mode==4:
        deletecachefiles(url)
		
elif mode==5:
        WIZARD(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       DeletePackages(url)
		
elif mode==150:
        MOVIESBUTTON1()

elif mode==151:
        MOVIESBUTTON2()

elif mode==152:        
	TVSHOWSBUTTON1()

elif mode==153:        
	TVSHOWSBUTTON2()
	
elif mode==154:
       KIDSBUTTON1()

elif mode==155:
       KIDSBUTTON2()

elif mode==156:
       LIVETVBUTTON1()

elif mode==165:
       LIVETVBUTTON2()
       
elif mode==157:
       MUSICBUTTON()

elif mode==158:
       SPORTSBUTTON1()

elif mode==159:
       SPORTSBUTTON2()

elif mode==160:
       ONLINEBUTTON1()

elif mode==161:
       ONLINEBUTTON2()

elif mode==162:
       ANIMEBUTTON()

elif mode==163:
       UPDATEBUTTON1()

elif mode==164:
       UPDATEBUTTON2()

elif mode==20:
       MOVIES1()

elif mode==21:
       MOVIES2()

elif mode==22:
       MOVIES3()

elif mode==23:
       MOVIES4()

elif mode==24:
       MOVIES5()

elif mode==30:
       TVSHOWS1()

elif mode==31:
       TVSHOWS2()

elif mode==32:
       TVSHOWS3()

elif mode==33:
       TVSHOWS4()

elif mode==34:
       TVSHOWS5()

elif mode==35:
       TVSHOWS6()

elif mode==40:
       KIDS1()

elif mode==41:
       KIDS2()

elif mode==42:
       KIDS3()

elif mode==43:
       KIDS4()

elif mode==44:
       KIDS5()

elif mode==45:
       KIDS6()

elif mode==50:
       LIVETV1()

elif mode==51:
       LIVETV2()

elif mode==52:
       LIVETV3()

elif mode==53:
       LIVETV4()

elif mode==54:
       LIVETV5()

elif mode==60:
       MUSIC1()

elif mode==61:
       MUSIC2()

elif mode==62:
       MUSIC3()

elif mode==63:
       MUSIC4()

elif mode==70:
       SPORTS1()

elif mode==71:
       SPORTS2()

elif mode==72:
       SPORTS3()

elif mode==73:
       SPORTS4()

elif mode==74:
       SPORTS5()
	   
elif mode==75:
       SPORTS6()

elif mode==80:
       ONLINE1()

elif mode==81:
       ONLINE2()

elif mode==82:
       ONLINE3()

elif mode==83:
       ONLINE4()

elif mode==84:
       ONLINE5()

elif mode==85:
       ONLINE6()

elif mode==90:
       ANIME1()

elif mode==91:
       ANIME2()

elif mode==92:
       ANIME3()

elif mode==93:
       ANIME4()

elif mode==100:
       UPDATE1()
       
elif mode==101:
       UPDATE2()
       
elif mode==102:
       UPDATE3()
       
elif mode==103:
       UPDATE4()

elif mode==104:
       UPDATE5()

elif mode==105:
       UPDATE6()

elif mode==106:
       UPDATE7()

elif mode==206:
       DELETEIVUEDB()
       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
